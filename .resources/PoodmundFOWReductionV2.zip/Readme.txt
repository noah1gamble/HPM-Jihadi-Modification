Installation Guide:

Drop the "FogOfWarReduction" folder contained within this .zip file into your "Victoria 2/mods" folder.

Configuration: 

Within the "Victoria 2\mod\FogOfWarReduction\gfx\FX" folder there are 2 files that are adjusted by this mod. The 1st line in each file explains how to adjust the transparency for the FOW for the Terrain tiles and also the Water tiles respectively.

Enjoy.